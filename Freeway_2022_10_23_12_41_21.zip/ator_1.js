// Ator
 
let ator1 = {
  xAtor : 85,
  yAtor : 366,
  colisao : false,
  meusPontos : 0
}
 
let ator2 = {
  xAtor : 385,
  yAtor : 366,
  colisao : false,
  meusPontos : 0
}
 
let atores = [ator1, ator2];
 
function mostraAtor(){
  image(imagemAtores[0], ator1.xAtor, ator1.yAtor, 30, 30);
  image(imagemAtores[1], ator2.xAtor, ator2.yAtor, 30, 30);
}
 
function movimentaAtor1(){
  if (keyIsDown(65)){
    if (podeSeMoverEsquerda(ator1)){
      ator1.xAtor -= 3;
    }
  }
  if (keyIsDown(68)){
    if (podeSeMoverDireita(ator1)){
      ator1.xAtor += 3;
    }
  }
  if (keyIsDown(87)){
    ator1.yAtor -= 3;
  }
  if (keyIsDown(83)){
    if (podeSeMover(ator1)){
      ator1.yAtor += 3;
    }
  }
}
 
function movimentaAtor2(){
  if (keyIsDown(LEFT_ARROW)){
    if (podeSeMoverEsquerda(ator2)){
      ator2.xAtor -= 3;
    }
  }
  if (keyIsDown(RIGHT_ARROW)){
    if (podeSeMoverDireita(ator2)){
      ator2.xAtor += 3;
    }
  }
  if (keyIsDown(UP_ARROW)){
    ator2.yAtor -= 3;
  }
  if (keyIsDown(DOWN_ARROW)){
    if (podeSeMover(ator2)){
      ator2.yAtor += 3;
    }
  }
}
 
function verificaColisaoAtor(ator){
  for (let j = 0; j < 2; j++){
    for (let i = 0; i < imagemCarros.length; i++){
      colisao = collideRectCircle(xCarros[i], yCarros[i], comprimentoCarro, alturaCarro, ator[j].xAtor, ator[j].yAtor, 15);
      if (colisao){
        voltaPosicaoInicialAtor(atores);
        somColisao.play()
        if (pontosMaiorQueZero(atores)){
          ator[j].meusPontos -= 1;
        }
      }
    }
  }
}
 
function voltaPosicaoInicialAtor(ator){  
  for (let i = 0; i < atores.length; i++){
    if (ator[i] === atores[0]){
      ator[i].xAtor = 85;
      ator[i].yAtor = 366;
      break;
    }
    if (ator[i] === atores[1]){
      ator[i].xAtor = 385;
      ator[i].yAtor = 366;
      break;
    }
  }
}
 
function incluiPontos1(){
  textAlign(CENTER);
  textSize(25);
  fill(color(255, 240, 60));
  text(ator1.meusPontos, 150, 27);
}
 
function incluiPontos2(){
  textAlign(CENTER);
  textSize(25);
  fill(color(255, 240, 60));
  text(ator2.meusPontos, 350, 27);
}
 
function marcaPontoAtor(ator){
  for (let i = 0; i < 2; i++){
    if(ator[i].yAtor < 15){
      ator[i].meusPontos += 1;
      somPonto.play();
      voltaPosicaoInicialAtor(atores);
    }
  }
}
 
function pontosMaiorQueZero(ator){
    return ator.meusPontos > 0;
}
 
function podeSeMover(ator){
      return ator.yAtor < 366;
}
 
 
function podeSeMoverDireita(ator){
    return ator.xAtor < 470;
}
 
function podeSeMoverEsquerda(ator){
    return ator.xAtor > 0;
}