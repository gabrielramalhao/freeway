// Imagens

let imagemEstrada;
let imagemAtor_1;
let imagemAtor_2;
let imagemCarro_1;
let imagemCarro_2;
let imagemCarro_3;

let somTrilha;
let somColisao;
let somPonto;

function preload(){
  imagemEstrada = loadImage("Imagens/estrada.png");
  imagemAtor_1 = loadImage("Imagens/ator-1.png");
  imagemAtor_2 = loadImage("Imagens/ator-1.png");
  imagemAtores = [imagemAtor_1, imagemAtor_2];
  imagemCarro_1 = loadImage("Imagens/carro-1.png");
  imagemCarro_2 = loadImage("Imagens/carro-2.png");
  imagemCarro_3 = loadImage("Imagens/carro-3.png");
  imagemCarros = [imagemCarro_1, imagemCarro_2, imagemCarro_3, imagemCarro_1, imagemCarro_2, imagemCarro_3];
  somTrilha = loadSound("Sons/trilha.mp3");
  somColisao = loadSound("Sons/colidiu.mp3");
  somPonto = loadSound("Sons/pontos.wav");
}