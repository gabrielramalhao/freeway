function setup() {
  createCanvas(500, 400);
  somTrilha.loop();
}

function draw() {
  background(imagemEstrada);
  mostraAtor();
  mostraCarro();
  movimentaCarro();
  movimentaAtor1();
  movimentaAtor2();
  voltaPosicaoInicial(atores);
  passouTodaTela();
  verificaColisaoAtor(atores);
  incluiPontos1();
  incluiPontos2();
  marcaPontoAtor(atores);
}
